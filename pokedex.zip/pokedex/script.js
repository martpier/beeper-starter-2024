async function fetchPokemon(id) {
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
    const data = await response.json();
    return data;
}

function displayPokemon(pokemon) {
    const pokemonList = document.getElementById('pokemon-list');

    // container
    const card = document.createElement('div');
    card.className = 'pokemon-card';

    // sprite
    const img = document.createElement('img');
    img.className = "sprite";
    img.src = pokemon.sprites.front_default;
    img.alt = pokemon.name;
    card.appendChild(img);

    // name
    const nameDiv = document.createElement('div');
    nameDiv.className = 'pokemon-name';
    nameDiv.textContent = pokemon.name;
    card.appendChild(nameDiv);

    // types
    const typeDiv = document.createElement('div');
    typeDiv.className = 'pokemon-type';
    const types = pokemon.types.map(t => t.type.name).join(', ');
    typeDiv.textContent = types;
    card.appendChild(typeDiv);

    pokemonList.appendChild(card);
}

async function loadPokedex() {
    const promises = [];
    for (let i = 1; i <= 20; i++) {
        promises.push(
            fetchPokemon(i)
        );
    }

    const results = await Promise.all(promises);

    for (const pokemon of results) {
        displayPokemon(pokemon);
    }
}

loadPokedex();
